function [ RMSE ] = pronySeries(x, t1,t2,tr, rate, data1,data2, termOpt)
% pronySeries is a function to fit indentation data with prony series
% 
% Input Variables:
% x - prony series parameters
% t1 - ramp time
% t2 - relaxation time
% tr - boundary point of t1 and t2
% rate - constant for non-infinite plate correction
% data1 - ramp force from experiment data
% data2 - relaxation force from experiment data
% termOpt - terms of prony series
%
% Output Variables:
% RMSE - root mean squre error
% 
% Record of Revisions
% Mar-03-2017===SQ,YF===Original Code
% Mar-04-2017===YF===Add comments, use RMSE
% June-19-2017===SQ===Change equations

if termOpt == 1
%     1 term
    Fcal1 = rate*(x(1)*t1-(x(2)*x(3)*(exp(-t1/x(3))-1)));
    Fcal2 = rate*(x(1)*tr+x(2)*x(3)*exp(-t2/x(3))*(exp(tr/x(3))-1));
elseif termOpt == 2
%     2 terms
    Fcal1 = rate*(x(1)*t1-(x(2)*x(4)*(exp(-t1/x(4))-1)+x(3)*x(5)*(exp(-t1/x(5))-1)));
    Fcal2 = rate*(x(1)*tr+x(2)*x(4)*exp(-t2/x(4))*(exp(tr/x(4))-1)+x(3)*x(5)*exp(-t2/x(5))*(exp(tr/x(5))-1));
elseif termOpt == 3  
%     3 terms
    Fcal1 = rate*(x(1)*t1-(x(2)*x(5)*(exp(-t1/x(5))-1)+x(3)*x(6)*(exp(-t1/x(6))-1)+x(4)*x(7)*(exp(-t1/x(7))-1)));
    Fcal2 = rate*(x(1)*tr+x(2)*x(5)*exp(-t2/x(5))*(exp(tr/x(5))-1)+x(3)*x(6)*exp(-t2/x(6))*(exp(tr/x(6))-1)+x(4)*x(7)*exp(-t2/x(7))*(exp(tr/x(7))-1));
else
%     4 terms
    Fcal1 = rate*(x(1)*t1-(x(2)*x(6)*(exp(-t1/x(6))-1)+x(3)*x(7)*(exp(-t1/x(7))-1)+x(4)*x(8)*(exp(-t1/x(8))-1)+x(5)*x(9)*(exp(-t1/x(9))-1)));
    Fcal2 = rate*(x(1)*tr+x(2)*x(6)*exp(-t2/x(6))*(exp(tr/x(6))-1)+...
        x(3)*x(7)*exp(-t2/x(7))*(exp(tr/x(7))-1)+x(4)*x(8)*exp(-t2/x(8))*(exp(tr/x(8))-1)+...
        x(5)*x(9)*exp(-t2/x(9))*(exp(tr/x(9))-1));
end

%     MSE=sum((data-Fcal).^2)/timelength;
timelength1 = length(data1);
timelength2 = length(data2);
RMSE =0.5*sqrt(sum((data1-Fcal1).^2)/timelength1)+0.5*sqrt(sum((data2-Fcal2).^2)/timelength2);
end
