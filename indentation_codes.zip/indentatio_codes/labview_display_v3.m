% Matlab codes for data displaying of labview-based equipment
%
% Output Variables:
% aa - number of whole test data
% thk - thicknesses of samples
% datalab0 - data acquired when in initial contact�սӴ�ʱ����
% datalab1 - actual indentation data ��ѹ��ȫ������ [180000points,force-displacement,5depth,6samples]
% indenterA��indenter areaѹͷ���
% indenterR��indenter radiusѹͷ�뾶
% [maxF, maxF_loc] - maximum value and index of the orignial force data acquired ԭ�������ֵ
% [minF, minF_loc] - minimum value and index of the orignial force data acquired ԭ������Сֵ
% [max2, max2loc] - maximum value and index of the flipped
%                   indentation-relaxation curve
% pts - [1x5], max2loc index value for all the indentation depth curves����ѹ�κͻָ��ηֽ��
% start_pt = 400;% the initial 1s (1e3 points) were acquired for waiting for the motor to warm up
% relaxFall - cell array containing all relaxation force (mN)
% rampFall - cell array containing all ramp force (mN)
% Fall - cell array containing all force (mN)
% fitFall - cell array containing all fitting results (mN)��5 rows represent
% 5 depths respectively and each column represent one sample data
% rampDispAll, relaxDispAll, dispAll - cell array containing all ramp,
%               relaxation, and all displacements (mm)
% displacement - (5depth,6samples) displacement of indentor for every depth and sample
% rampVelocity - velocity of indentor for every depth and sample

%
% Record of Revision
% May-14-2018===SQ===Original Code
% April-15-2021===CY===Batch process
%% clear and reset data ��������
clear all
clc
close
aa = 0;
% addpath('C:\matlab\2017')
% addpath('C:\mouse\mousecancer')
loadCellRatio = 24; % mN/V

laserSensorRatio = 6; % mm/V uigetfile
indenterR = 1; % mm
indenterA = indenterR^2*pi; % mm2
windowSize = 50;
addpath('D:\matlab_code\indentation_code') %�ǵ��޸�·��
%lset parameters
aa = aa+1;   % counting
fname0 = {'8'};%name for injury palces
fname1 = {'healthy_8'};%name for healthy places
color = {'r', 'y', 'g', 'c', 'b', 'm'};%color for ploting
temp = [fname0{1}, '%.xlsx'];
parameter = {};
line_x = 1;
line_y = 1;
%load data
fd_seed = dir;
fd_seed(1:2,:) = [];
for fd = 1:length(fd_seed)
    cd([fd_seed(fd).folder,'\',fd_seed(fd).name]);
    fd_sub = dir;
    fd_sub(1:2,:) = [];
    parameter(line_x,line_y) = {['sample_',fd_seed(fd).name]};
    for var = [{'C0'},{'C1'},{'C2'},{'tau1'},{'tau2'},{'R2'},{'G0'},{'Ginf'}]
        line_y = line_y + 1;
        parameter(line_x,line_y) = var;
    end
    for fds = 1:length(fd_sub)
        cd([fd_sub(fds).folder,'\',fd_sub(fds).name]);
        if exist(temp)==2
            for ii =1:size(fname0,2)
                %  indentation data
                temp1 = 0;
                tempname1 = [fname0{ii},'%','.xlsx'];
                temp1 = xlsread(tempname1);
                delaytime = temp1(1,1);
                temp1(1,:) = [];
                temp1 = filter(ones(1,windowSize)/windowSize,1,temp1); %noise canceling
                temp1(:,[1,2])=temp1(:,[2,1]);
                if length(temp1(:,1)) < 180000
                    temp1(length(temp1(:,1))+1:180000,1)= temp1(end,1);
                    temp1(length(temp1(:,1))+1:180000,2)= temp1(end,2);
                end
                datalab1(:,:,ii,aa) = temp1;
            end
            inf = xlsread('SampleInfo.xlsx');
            thk(aa) = inf(5,1);
            dis_inden(aa) = inf(14,5);
        else
            for jj =1:size(fname1,2)
                %  indentation data
                temp2 = 0;
                tempname2 = [fname1{jj},'%','.xlsx'];
                temp2 = xlsread(tempname2);
                temp2 = filter(ones(1,windowSize)/windowSize,1,temp2); %noise canceling
                temp2(:,[1,2])=temp2(:,[2,1]);
                if length(temp2(:,1)) < 180000
                    temp2(length(temp2(:,1))+1:180000,1)= temp2(end,1);
                    temp2(length(temp2(:,1))+1:180000,2)= temp2(end,2);
                end
                
                datalab1(:,:,jj,aa) = temp2;
                
            end
            inf = xlsread('healthyInfo.xlsx');
            thk(aa) = inf(5,1);
            dis_inden(aa) = inf(14,5);
        end
        
        %24->260,22->250,6:8->100
        
        % diaplay
        switch delaytime
            case {6}
                start_pt = 85;
            case {8}
                start_pt = 100;
            case {11}
                start_pt = 130;
            case {17}
                start_pt = 198;
            case {22}
                start_pt = 255;
            case {24}
                start_pt = 260;
            otherwise
                start_pt = 1;
        end
        
        % start_pt = 100;
        % the initial 1s (1e3 points) were acquired for waiting for the motor to warm up
        smoothRatio = 2000;
        smoothRatio2 = 10000;
        thk = thk';
        for jj = 1:size(datalab1, 3) % for each indentation depth
            for ii = 1:size(datalab1, 4) % for each sample
                
                % get one FD curve
                data1 = datalab1(:,:,jj,ii);
                
                %         relaxation time selection
                %         relaxationtime = 180;
                %         data1(1000*relaxationtime:end,:) = [];
                
                % find the contact point - by zero displacement
                [maxD, maxD_loc] = max(data1(start_pt:end, 2));
                contactPt = start_pt + maxD_loc - 1; %contact point��¼���Ǵ�ʵ�����ݲɼ��㵽������㣻�����۳�ʼλ��
                % find the minimal indentation force and its location, this is the peak force
                [minF, minF_loc] = min(data1(contactPt:end,1));
                % the minimal force indentation location index in the whole vector
                peakPt = minF_loc + contactPt - 1; %peakPt��¼������С������λ��
                
                rampF = data1(contactPt:peakPt,1); %rampF ��¼�ӽӴ�����С������֮ǰ��Ҳ������ѹ�Ĺ���
                rampDisp = data1(contactPt:peakPt,2); %rampDisp ��¼λ�����߱仯
                relaxF = data1(peakPt:end, 1); %��¼�ָ�����
                relaxDisp = data1(peakPt:end, 2);
                contactPts(jj,ii) = contactPt;  %����Ӵ���
                peakPts(jj,ii) = peakPt;   %����ָ���ʼ��ʱ���
                
                % find the max indentation force/displacement and its location, this is the original data before flipping
                [maxF, maxF_loc] = max(data1(contactPt:end, 1));  %Ѱ�ҳ�ʼ����С
                
                % ramp force/displacement - corrected
                rampforce = (-rampF + maxF)*loadCellRatio;    %������λ�Ƶ��½���ת��Ϊ������
                rampDisp_cor = (rampDisp(1) - rampDisp)*laserSensorRatio;
                % relaxation force/displacement - corrected
                relaxationforce = (-relaxF + maxF)*loadCellRatio; %���ָ����̵�����λ�Ʊ�Ϊ�½���
                relaxDisp_cor = (rampDisp(1) - relaxDisp)*laserSensorRatio;
                
                % smooth data
                relaxationforce = smooth(relaxationforce, smoothRatio);
                rampforce = smooth(rampforce, smoothRatio);
                relaxDisp_cor = smooth(relaxDisp_cor, smoothRatio);
                rampDisp_cor = smooth(rampDisp_cor, smoothRatio);
                
                relaxationforce =  smooth(relaxationforce, smoothRatio2);
                rampforce = smooth(rampforce, smoothRatio2);
                relaxDisp_cor = smooth(relaxDisp_cor, smoothRatio2);
                relaxDisp_cor = smooth(relaxDisp_cor, smoothRatio2);
                
                % ramp and relaxation force after y axis correction
                relaxationforce = relaxationforce - rampforce(1); %��һ������0��ʼ
                rampforce = rampforce - rampforce(1);
                
                %         rampforce = rampforce(end-100:end);
                relaxFall{jj,ii} = relaxationforce;
                rampFall{jj,ii} = rampforce;
                Fall{jj,ii} = [rampforce; relaxationforce];
                
                % normalization with respect to Fmax
                normFrelax{jj,ii} = relaxationforce./relaxationforce(1);
                normFramp{jj,ii} = rampforce./relaxationforce(1);
                normFall{jj,ii} =  [rampforce; relaxationforce]./relaxationforce(1);
                
                % for displacement
                rampDispAll{jj,ii} = rampDisp_cor;
                relaxDispAll{jj,ii} = relaxDisp_cor;
                dispAll{jj,ii} = [rampDisp_cor; relaxDisp_cor];
                displacement(jj,ii) = max(rampDispAll{jj,ii})-min(rampDispAll{jj,ii});%displacement��mm
                
                %shrink the displacement unit
                %         displacement(jj,ii) = 1e-3*displacement(jj,ii);
                
                rampVelocity(jj,ii) = displacement(jj,ii)/length( rampDispAll{jj,ii} );% velocity mm/ms
                strainrate = rampVelocity(jj,ii) / thk * 1000;
            end
        end
        
        % check data
        for ii = 1:size(relaxFall,2) % for each sample
            figure('name',[fd_seed(fd).name,'_',fd_sub(fds).name]),
            for jj = 1:size(relaxFall,1) % for each indentation depth
                subplot(1,2,1); plot(Fall{jj,ii},color{jj}); hold on
                title('Force','FontName','Times New Roman','FontSize',28);
                subplot(1,2,2); plot(dispAll{jj,ii}, color{jj}); hold on;
                title('Displacement','FontName','Times New Roman','FontSize',28);
                %         subplot(1,2,1); plot(rampDispAll{jj,ii},color{jj}); hold on
                %         subplot(1,2,2); plot(relaxDispAll{jj,ii}, color{jj}); hold on;
            end
            saveas(gcf,'indentation_curve.jpg');
        end
        % % save('data.mat');
        % %
        
        % %% fitting
        termOpt = 2; % term of prony series ����
        N = 3; % number of cycles of circuit fitting
        Fcalploy = 0; %final fitting results
        %smoothRatio2 = 100000;
        
        options1 = optimset('fminsearch');%���ѡ������
        % options1.TolX = 1e-100;
        % options1.TolFun = 1e-100;
        % options1.MaxIter = 1000000000;
        options1.Display = 'off';
        
        options = optimset('fmincon');%���ѡ������
        options.TolX = 1e-100;
        options.TolFun = 1e-100;
        options.MaxIter = 100000000;
        options.Generations = 200;
        options.Display = 'off';
        
        %options2 = optimoptions('ga','Display', 'off');
        % options2=optimset('ga');%������ϲ�  ��
        % options2.TolX=1e-100;
        % options2.TolCon=1e-100;
        % options2.TolFun=1e-100;
        % options2.MaxIter=10000000000;
        % options2.Generations = 200;
        % options2.Display='off';
        %fh3 = figure;
        %start to fit the data
        num = 0;
        for ii = 1:1%size(datalab1, 4)% for each sample
            %figure(ii);
            num = num+1; % print the numble of sample
            xcoe = zeros(size(datalab1, 3), 2*termOpt+2);
            for jj = 1:size(datalab1, 3) % for each indentation depth
                RMSE = 10; %referenc value for RMSE
                rR2 = 0.95;
                for kk = 1:1%�����������ѽ��
                    %coe = 0;
                    c = 0;
                    x = 0;
                    %Fcalploy = 0;
                    t1 = [1:1:length( rampFall{jj,ii} )]';%��ѹʱ��
                    t2 = [(length(rampFall{jj,ii} ) + 1):1:length( Fall{jj,ii} )]';%�ָ�ʱ��
                    t3 = [1:1:length( relaxFall{jj,ii} )]';%���ָ�ʱ��
                    tr = length( rampFall{jj,ii});%��ѹ�ָ��ֽ��
                    
                    %             % time index regulization
                    %             t1 = t1/180;
                    %             t2 = t2/180;
                    %             t3 = t3/180;
                    %             tr = tr/180;
                    
                    relaxationforce =  relaxFall{jj,ii};
                    %relaxationforce =  smooth(relaxationforce, smoothRatio2);
                    rampforce = rampFall{jj,ii};%���ݶ�ȡ
                    %rampforce =  smooth(rampforce, smoothRatio2);
                    
                    %             shrink the force unit
                    %             relaxationforce = 1e-3*relaxationforce;
                    %             rampforce = 1e-3*rampforce;
                    
                    Force = [rampforce; relaxationforce];
                    
                    p = sqrt(indenterR*displacement(jj,ii))/thk(ii);
                    X = (1+1.133*p+1.283*p^2+0.769*p^3+0.0975*p^4);
                    rate = (8*indenterR*rampVelocity(jj,ii)*X);%������
                    
                    %�Ų��㷨��һ���ֵ
                    %[x,sfval1,sexit1,soutput1]=ga(@(x)  pronySeriesramp(x,t1,tr,rate,  rampforce,termOpt),7,[],[],[],[],[0.01 0.01 0.01 0.01 20 20 20],[],[],options2);
                    [x,sfval1,sexit1,soutput1]=ga(@(x)  pronySeriesrelax(x,t2,tr,rate, relaxationforce,termOpt),2*termOpt+1,[],[],[],[],[0.01 0.01 0.01 65 65],[],[]);
                    %             [x,sfval1,sexit1,soutput1]=ga(@(x)  pronySeries(x,t1,t2,tr,rate, rampforce,relaxationforce,termOpt),7,[],[],[],[],[0.001 0.001 0.001 0.001 65 65 65],[],[],options2);
                    x1 = x;%����Ϊ��ֵ
                    
                    %             circuit fitting in order to reduce errors
                    for mm = 1:N
                        c = x;
                        %[x,sfval1,sexit1,soutput1] = fminsearch(@pronySeries, c, options, t1, rate, relaxationforce,termOpt);%���
                        [x,sfval1,sexit1,soutput1]=fmincon(@(x) pronySeries(x,t1,t2,tr,rate,rampforce,relaxationforce,termOpt),c,[],[],[],[],[0.01 0.01 0.01 65 65],[],[],options);
                        %                  [x,sfval1,sexit1,soutput1]=fmincon(@(x) pronySeriesrelax(x,t2,tr,rate, relaxationforce,termOpt),c,[],[],[],[],[0.001 0.001 0.001 65 65],[],[],options);
                    end
                    
                    %coe(jj,:) = x;%�������ϵ��
                    Fcal = 0;%����,��ֹ���ݳ��Ȳ�һ
                    
                    % fitted force
                    %�����Ϻ�Ľ��
                    if termOpt == 1
                        % 1 term
                        Fcal1 = rate*(x(1)*t1-(x(2)*x(3)*(exp(-t1/x(3))-1)));
                        Fcal2 = rate*(x(1)*tr+x(2)*x(3)*exp(-t2/x(3))*(exp(tr/x(3))-1));
                        Fcal = [Fcal1; Fcal2];
                    elseif termOpt == 2
                        % 2 terms
                        Fcal1 = rate*(x(1)*t1-(x(2)*x(4)*(exp(-t1/x(4))-1)+x(3)*x(5)*(exp(-t1/x(5))-1)));
                        Fcal2 = rate*(x(1)*tr+x(2)*x(4)*exp(-t2/x(4))*(exp(tr/x(4))-1)+x(3)*x(5)*exp(-t2/x(5))*(exp(tr/x(5))-1));
                        Fcal = [Fcal1; Fcal2];
                    elseif termOpt == 3
                        % 3 terms
                        Fcal1 = rate*(x(1)*t1-(x(2)*x(5)*(exp(-t1/x(5))-1)+x(3)*x(6)*(exp(-t1/x(6))-1)+x(4)*x(7)*(exp(-t1/x(7))-1)));
                        Fcal2 = rate*(x(1)*tr+x(2)*x(5)*exp(-t2/x(5))*(exp(tr/x(5))-1)+x(3)*x(6)*exp(-t2/x(6))*(exp(tr/x(6))-1)+x(4)*x(7)*exp(-t2/x(7))*(exp(tr/x(7))-1));
                        Fcal = [Fcal1; Fcal2];
                    else
                        Fcal1 = rate*(x(1)*t1-(x(2)*x(6)*(exp(-t1/x(6))-1)+x(3)*x(7)*(exp(-t1/x(7))-1)+x(4)*x(8)*(exp(-t1/x(8))-1)+x(5)*x(9)*(exp(-t1/x(9))-1)));
                        Fcal2 = rate*(x(1)*tr+x(2)*x(6)*exp(-t2/x(6))*(exp(tr/x(6))-1)+...
                            x(3)*x(7)*exp(-t2/x(7))*(exp(tr/x(7))-1)+x(4)*x(8)*exp(-t2/x(8))*(exp(tr/x(8))-1)+...
                            x(5)*x(9)*exp(-t2/x(9))*(exp(tr/x(9))-1));
                        Fcal = [Fcal1; Fcal2];
                    end
                    
                    Fcal=Fcal';
                    %MSE(ii) =  sum((relaxationforce-Fcal).^2)/reltimelen(ii);%������ϵ��
                    RMSE2 = 0.5*sqrt(sum((rampforce-Fcal1).^2)/length(rampforce)...
                        +0.5*sqrt(sum((relaxationforce-Fcal2).^2)/length(relaxationforce)));%������ϵ��
                    %���ںϲ����ֵ���Ӧ���ϵ������
                    [siR2, SStot, SSreg, SSres] = R2cal(Fall{jj,ii}',Fcal);
                    %��ο�ֵ�Աȣ�ȡ����ѽ��
                    if siR2 > rR2
                        break
                    else
                        continue
                    end
                end
                %��������
                xcoe(jj,1:2*termOpt+1) = x;
                %RR2 = siR2;
                %xcoe(jj,6) = RMSE2;%�ϲ����ֵ���Ӧ�����ϵ��
                xcoe(jj,2*termOpt+2) = siR2;
                CtauRMSER2{jj,ii} = xcoe(jj,:);
                fitFall{jj,ii} = Fcal;
                R2(ii,jj) = siR2;
                %[R2(jj,ii), SStot(jj,ii), SSreg(jj,ii), SSres(jj,ii)] = R2cal(Fall{jj,ii}',fitFall{jj,ii});
                
                % subplot(2,2,(ii-1))%��ͼ
                figure('name',[fd_seed(fd).name,'_',fd_sub(fds).name]),
                xt = [0:length(Fcal)-1]/1000;
                plot(xt,Force,color{jj},'LineWidth',2);
                hold on
                plot (xt,Fcal,'k--','LineWidth',2);
                box off
                set(gca,'fontsize',12);
                xlim([0 180])
                xticks([0 60 120 180])
                legend("Experimental","Fitted");
                set(legend,'box','off');
                xlabel('Time (s)'),ylabel('Force (mN)');
                set(gca,'fontsize',24);
                saveas(gcf,'fitted_curve.jpg');
                
            end
            %     title(ii,'FontName','Times New Roman','FontSize',28);
        end
        save('data.mat','xcoe');
        line_x = line_x + 1;
        line_y = 1;
        parameter(line_x,line_y) = {fd_sub(fds).name};
        for line_y = 2:7
            parameter(line_x,line_y) = {num2str(xcoe(line_y-1),'%.3f')};
        end
        parameter(line_x,8) = {num2str(sum(xcoe(1:3)),'%.3f')};
        parameter(line_x,9) = {num2str(xcoe(1),'%.3f')};
    end
    line_x = line_x + 2;
    line_y = 1;
end
close all;
cd ../..
save('data.mat','parameter');
xlswrite('data.xlsx',parameter);
fprintf('End of Processing\n');
%R2mean = mean(R2,2);
%print(fh3, '-dtiff', '-r300','Fitting');%����ͼ��
%save FinalResults.mat%����ȫ������