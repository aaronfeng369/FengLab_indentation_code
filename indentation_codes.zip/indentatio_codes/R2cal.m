function [R2, SStot, SSreg, SSres] = R2cal(y, f)
% function R2cal is to calculate R2 value for goodness of fit
% 
% Input Variables:
% y - A data set has n values marked y1...yn (collectively known as yi),
%   this is the observed data from experiment
% f - each associated with a predicted (or modeled) value  f1...fn (known as fi, or sometimes ?i).
%   This is regression fitted data
% 
% Output Variables:
% R2 - regular R2 value
% 
% Record of Revision
% Feb-25-2016===YF===Original Code
% Mar-24-2017===YF===Add outputs

% If ybar is the mean of the observed data
ybar = mean(y);

% The total sum of squares (proportional to the variance of the data):
SStot = sum((y - ybar).^2);

% The regression sum of squares, also called the explained sum of squares:
SSreg = sum((f - ybar).^2);

% The sum of squares of residuals, also called the residual sum of squares:
SSres = sum((y - f).^2);

% The most general definition of the coefficient of determination is
R2 = 1 - SSres/SStot;
