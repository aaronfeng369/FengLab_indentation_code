function [ RMSE ] = pronySeriesrelax(x,t2,tr, rate, data2, termOpt)
% pronySeries is a function to fit indentation data with prony series
% 
% Input Variables:
% x - prony series parameters
% t2 - relaxation time
% tr - boundary point
% rate - constant for non-infinite plate correction
% data2 - relaxation force from experiment data
% termOpt - terms of prony series
%
% Output Variables:
% RMSE - root mean squre error
% 
% Record of Revisions
% Mar-03-2017===SQ,YF===Original Code
% Mar-04-2017===YF===Add comments, use RMSE
% June-19-2017===SQ===Change equations

if termOpt == 1
    % 1 term
    Fcal2 = rate*(x(1)*tr+x(2)*x(3)*exp(-t2/x(3))*(exp(tr/x(3))-1));
elseif termOpt == 2
    % 2 terms
    Fcal2 = rate*(x(1)*tr+x(2)*x(4)*exp(-t2/x(4))*(exp(tr/x(4))-1))+x(3)*x(5)*exp(-t2/x(5))*(exp(tr/x(5))-1);
elseif termOpt == 3
    % 3 terms
    Fcal2 = rate*(x(1)*tr+x(2)*x(5)*exp(-t2/x(5))*(exp(tr/x(5))-1)+...
        x(3)*x(6)*exp(-t2/x(6))*(exp(tr/x(6))-1)+x(4)*x(7)*exp(-t2/x(7))*(exp(tr/x(7))-1));
else
    Fcal2 = rate*(x(1)*tr+x(2)*x(6)*exp(-t2/x(6))*(exp(tr/x(6))-1)+...
        x(3)*x(7)*exp(-t2/x(7))*(exp(tr/x(7))-1)+x(4)*x(8)*exp(-t2/x(8))*(exp(tr/x(8))-1)+...
        x(5)*x(9)*exp(-t2/x(9))*(exp(tr/x(9))-1));
end

%     MSE=sum((data-Fcal).^2)/timelength;
timelength2 = length(data2);
RMSE = sqrt(sum((data2-Fcal2).^2)/timelength2);
    
end